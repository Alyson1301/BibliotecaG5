using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace PrograAvanBiblioteca.Pages
{
    public class nuevaClaveModel : PageModel
    {
        private readonly IHttpClientFactory _clientFactory;

        public nuevaClaveModel(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        [BindProperty(SupportsGet = true)]
        public string Correo { get; set; }

        [BindProperty(SupportsGet = true)]
        public string Token { get; set; }

        [BindProperty]
        public string NuevaContrase�a { get; set; }

        public string Mensaje { get; set; }
        public bool Exito { get; set; }

        // Asigna los par�metros de la URL al cargar la p�gina
        public void OnGet(string correo, string token)
        {
            Correo = correo;
            Token = token;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(NuevaContrase�a) || string.IsNullOrEmpty(Correo) || string.IsNullOrEmpty(Token))
            {
                Mensaje = "Todos los campos son obligatorios.";
                return Page();
            }

            var cliente = _clientFactory.CreateClient();
            var url = $"https://localhost:7058/api/Usuarios/resetearPassword";

            var datos = new
            {
                Correo = Correo,
                NuevaContrase�a = NuevaContrase�a,
                Token = Token
            };

            var contenido = new StringContent(JsonSerializer.Serialize(datos), Encoding.UTF8, "application/json");
            var respuesta = await cliente.PutAsync(url, contenido);

            if (respuesta.IsSuccessStatusCode)
            {
                Mensaje = "Contrase�a actualizada correctamente.";
                Exito = true;
            }
            else
            {
                Mensaje = "Error al actualizar la contrase�a.";
                Exito = false;
            }

            return Page();
        }
    }
}
