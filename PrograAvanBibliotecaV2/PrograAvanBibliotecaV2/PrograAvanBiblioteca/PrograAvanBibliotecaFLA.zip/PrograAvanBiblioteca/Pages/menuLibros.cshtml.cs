using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace PrograAvanBiblioteca.Pages
{
    public class menuLibrosModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public menuLibrosModel(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public List<LibroG5> Libros { get; set; } = new List<LibroG5>();
        public string Mensaje { get; set; } = string.Empty;

        public async Task OnGetAsync()
        {
            var client = _httpClientFactory.CreateClient();

            var response = await client.GetAsync("https://localhost:7058/api/Libros");

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadFromJsonAsync<List<LibroG5>>();

                if (jsonResponse != null)
                {
                    Libros = jsonResponse;

                    // Obtener detalles de cada autor y categor�a de libro
                    foreach (var libro in Libros)
                    {
                        var autorResponse = await client.GetAsync($"https://localhost:7058/api/Autores/{libro.ID_Libro}");
                        if (autorResponse.IsSuccessStatusCode)
                        {
                            var autorJson = await autorResponse.Content.ReadFromJsonAsync<AutorG5>();
                            libro.Autor = autorJson ?? new AutorG5();
                        }
                        else
                        {
                            libro.Autor = new AutorG5();
                        }

                        var categoriaResponse = await client.GetAsync($"https://localhost:7058/api/Categorias/{libro.ID_Libro}");
                        if (categoriaResponse.IsSuccessStatusCode)
                        {
                            var categoriaJson = await categoriaResponse.Content.ReadFromJsonAsync<CategoriaG5>();
                            libro.Categoria = categoriaJson ?? new CategoriaG5();
                        }
                        else
                        {
                            libro.Categoria = new CategoriaG5();
                        }
                    }
                }
            }
            else
            {
                Mensaje = "Error al obtener los datos de libros.";
            }
        }

        public class LibroG5
        {
            [JsonPropertyName("id_Libro")]
            public int ID_Libro { get; set; }

            [JsonPropertyName("titulo")]
            public string Titulo { get; set; } = string.Empty;

            [JsonPropertyName("autor")]
            public AutorG5 Autor { get; set; } = new AutorG5();

            [JsonPropertyName("categoria")]
            public CategoriaG5 Categoria { get; set; } = new CategoriaG5();

            [JsonPropertyName("isbn")]
            public string ISBN { get; set; } = string.Empty;

            [JsonPropertyName("a�o_Publicaci�n")]
            public int A�o_Publicaci�n { get; set; }
        }

        public class AutorG5
        {
            [JsonPropertyName("nombre")]
            public string Nombre { get; set; } = string.Empty;
        }

        public class CategoriaG5
        {
            [JsonPropertyName("nombre")]
            public string Nombre { get; set; } = string.Empty;
        }
    }
}


