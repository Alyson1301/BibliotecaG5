using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Mail;
using System.Net;

namespace PrograAvanBiblioteca.Pages
{
    public class reseteoClaveModel : PageModel
    {
        [BindProperty]
        public string Correo { get; set; }

        public string Mensaje { get; set; }
        public bool Exito { get; set; }

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(Correo))
            {
                Mensaje = "El correo es requerido.";
                Exito = false;
                return Page();
            }

            var token = Guid.NewGuid().ToString();

            try
            {
                var resetLink = Url.Page("/nuevaClave", null, new { token = token, email = Correo }, Request.Scheme);
                var subject = "Restablecimiento de Contrase�a - Biblioteca Fausto Herrera";
                var body = $"Haga clic en este enlace para restablecer su contrase�a: <a href='{resetLink}'>Restablecer</a>";

                using var smtp = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("bricenoc506@gmail.com", "lxte nsud zhch yrmc"),
                    EnableSsl = true
                };

                var message = new MailMessage("bricenoc506@gmail.com", Correo, subject, body)
                {
                    IsBodyHtml = true
                };

                await smtp.SendMailAsync(message);

                Mensaje = "Se ha enviado un enlace de restablecimiento a tu correo.";
                Exito = true;
            }
            catch (Exception ex)
            {
                Mensaje = $"Error al enviar el correo. Intenta m�s tarde. Detalles: {ex.Message}";
                Exito = false;
            }

            return Page();
        }
    }
}
