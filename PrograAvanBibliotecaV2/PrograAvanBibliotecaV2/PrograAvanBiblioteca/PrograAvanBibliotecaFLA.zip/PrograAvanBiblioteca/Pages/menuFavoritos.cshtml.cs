using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PrograAvanBiblioteca.Pages
{
    public class menuFavoritosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
