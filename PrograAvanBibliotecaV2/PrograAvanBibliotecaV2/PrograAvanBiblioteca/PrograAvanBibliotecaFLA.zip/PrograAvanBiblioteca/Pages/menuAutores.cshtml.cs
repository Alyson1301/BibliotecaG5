using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace PrograAvanBiblioteca.Pages
{
    public class menuAutoresModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public menuAutoresModel(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public List<AutorG5> Autores { get; set; } = new List<AutorG5>();
        public string Mensaje { get; set; } = string.Empty;

        public async Task OnGetAsync()
        {
            var client = _httpClientFactory.CreateClient();

            var response = await client.GetAsync("https://localhost:7058/api/Autores");

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadFromJsonAsync<List<AutorG5>>();

                if (jsonResponse != null)
                {
                    Autores = jsonResponse;

                    // Obtener los libros de cada autor
                    foreach (var autor in Autores)
                    {
                        var libroResponse = await client.GetAsync($"https://localhost:7058/api/Libros/{autor.ID_Autor}");
                        if (libroResponse.IsSuccessStatusCode)
                        {
                            var libroJson = await libroResponse.Content.ReadFromJsonAsync<List<LibroG5>>();
                            autor.Libros = libroJson ?? new List<LibroG5>();
                        }
                        else
                        {
                            autor.Libros = new List<LibroG5>();
                        }
                    }
                }
            }
            else
            {
                Mensaje = "Error al obtener los datos de autores.";
            }
        }

        public class AutorG5
        {
            [JsonPropertyName("id_Autor")]
            public int ID_Autor { get; set; }

            [JsonPropertyName("nombre")]
            public string Nombre { get; set; } = string.Empty;

            [JsonPropertyName("nacionalidad")]
            public string Nacionalidad { get; set; } = string.Empty;

            [JsonPropertyName("libros")]
            public List<LibroG5> Libros { get; set; } = new List<LibroG5>();
        }

        public class LibroG5
        {
            [JsonPropertyName("titulo")]
            public string Titulo { get; set; } = string.Empty;
        }
    }
}