var builder = WebApplication.CreateBuilder(args);

// Registrar servicios
builder.Services.AddRazorPages();
builder.Services.AddHttpClient();
builder.Services.AddDistributedMemoryCache(); // A�ADIR ANTES DEL BUILD
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configurar middlewares
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession(); // USAR DESPU�S DE UseRouting Y ANTES DE los endpoints
app.UseAuthorization();

app.MapRazorPages();

app.Run();
